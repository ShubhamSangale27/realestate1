import 'package:flutter/material.dart';
import 'package:real_estate/pages/property_detail.dart';
import 'package:real_estate/theme/color.dart';
import 'package:real_estate/utils/data.dart';
import 'package:real_estate/widgets/category_item.dart';
import 'package:real_estate/widgets/custom_textbox.dart';
import 'package:real_estate/widgets/property_item.dart';
import 'package:real_estate/widgets/icon_box.dart';

class PropertyPage extends StatefulWidget {
  const PropertyPage({ Key? key }) : super(key: key);

  @override
  _PropertyPageState createState() => _PropertyPageState();
}

class _PropertyPageState extends State<PropertyPage> {
  @override
  Widget build(BuildContext context) {
    return 
    CustomScrollView(
        slivers: <Widget>[
          SliverAppBar(
            backgroundColor: appBgColor,
            pinned: true,
            snap: true,
            floating: true,
            title: getHeader()
          ),
          SliverToBoxAdapter(
            child: getBody()
          )
        ],
      );
  }

  getHeader(){
    return
      Container(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text("Properties",
              style: TextStyle(color: Colors.black87, fontSize: 22, fontWeight: FontWeight.bold),
            ),
            // IconBox(child: Icon(Icons.search, color: Colors.white,), bgColor: primary.withOpacity(.8),)
          ],
        ),
      );
  }

  getBody(){
    return
      SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 15, right: 15),
              child: Row(
                children: [
                  Expanded(
                    child: CustomTextBox(hint: "Search", prefix: Icon(Icons.search, color: Colors.grey), )
                  ),
                  SizedBox(width: 10,),
                  IconBox(child: Icon(Icons.filter_list_rounded, color: Colors.white), bgColor: secondary, radius: 10,)
                ],
              ),
            ),
            SizedBox(height: 20,),
            listCategories(),
            SizedBox(height: 20,),
            listProperties(),
            SizedBox(height: 20,),
          ],
        ),
      );
  }
  
  int selectedCategory = 0;
  listCategories(){
    List<Widget> lists = List.generate(categories.length, 
      (index) => CategoryItem(data: categories[index], selected: index == selectedCategory,
        onTap: (){
          setState(() {
            selectedCategory =  index;
          });
        },
      )
    );
    return
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.only(bottom: 5, left: 15),
        child: Row(
          children: lists
        ),
      );
  }

  listProperties(){
    return
      Column(
        children: List.generate(properties.length, 
          (index) => PropertyItem(data: properties[index], index: index,
            onTap: (){
              Navigator.push(context, 
                MaterialPageRoute(builder: (context) => PropertyDetail(data: properties[index],))
              );
            },
            onFavoriteTap: (){
              setState(() {
                properties[index]["is_favorited"] = ! properties[index]["is_favorited"];
              });
            }
          )
        ),
      );
  }

}