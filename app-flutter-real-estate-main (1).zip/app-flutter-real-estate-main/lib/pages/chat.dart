import 'package:flutter/material.dart';
import 'package:real_estate/theme/color.dart';
import 'package:real_estate/utils/data.dart';
import 'package:real_estate/widgets/chat_item.dart';
import 'package:real_estate/widgets/icon_box.dart';

class ChatPage extends StatefulWidget {
  const ChatPage({ Key? key }) : super(key: key);

  @override
  _ChatPageState createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  @override
  Widget build(BuildContext context) {
    return 
    CustomScrollView(
        slivers: <Widget>[
          SliverAppBar(
            backgroundColor: appBgColor,
            pinned: true,
            snap: true,
            floating: true,
            title: getHeader()
          ),
          SliverToBoxAdapter(
            child: getBody()
          )
        ],
      );
  }

  getHeader(){
    return
      Container(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text("Chats",
              style: TextStyle(color: Colors.black87, fontSize: 22, fontWeight: FontWeight.bold),
            ),
            IconBox(child: Icon(Icons.search, color: darker,), bgColor: appBgColor)
          ],
        ),
      );
  }

  getBody(){
    return
      SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            getChats(),
            SizedBox(height: 20,),
          ],
        ),
      );
  }

  getChats(){
    return
      ListView(
        physics: NeverScrollableScrollPhysics(),
        padding: EdgeInsets.all(10),
        shrinkWrap: true,
        children: List.generate(chats.length, 
        (index) => ChatItem(chats[index],
            onTap: (){
              
            },
          )
        )
    );
  }

}